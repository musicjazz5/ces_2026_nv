# Vera Rubin 網絡互連指南：ConnectX、NVLink 6 與 Spectrum-X

**作者**: Manus AI  
**日期**: 2026年1月21日

## 執行摘要

本指南詳細說明了如何在 NVIDIA Vera Rubin AI 基礎設施中透過 ConnectX 網卡實現 Scale-up 和 Scale-out 網絡連接。Vera Rubin 架構採用了分層的網絡設計，其中 NVLink 6 負責機架內的高速 GPU 通信（Scale-up），而 Spectrum-X Ethernet 則負責機架間的通信（Scale-out）。ConnectX-9 SuperNIC 作為關鍵的集成組件，同時支持這兩種連接模式。

## 一、Vera Rubin 網絡架構概述

### 1.1 分層網絡設計

Vera Rubin 採用了業界領先的分層網絡架構，將 GPU 通信分為兩個不同的層級：

| 層級 | 技術 | 帶寬 | 範圍 | 用途 |
| --- | --- | --- | --- | --- |
| **Scale-up** | NVLink 6 | 14.4 Tbit/s per GPU | 單個機架 (≤2m) | GPU 間高速通信 |
| **Scale-out** | Spectrum-X Ethernet | 800 Gb/s per port | 跨機架/數據中心 | 機架間通信 |

### 1.2 Vera Rubin NVL144 Rack 的網絡配置

Vera Rubin NVL144 是標準的機架配置，包含 18 個 compute trays，每個 tray 內集成了 4 個 ConnectX-9 SuperNIC 板。以下是完整的網絡拓撲：

![NVIDIA Vera Rubin Network Architecture](https://private-us-east-1.manuscdn.com/sessionFile/ZIGxcF7hsICy1wl84JPlpQ/sandbox/kCtfMLeKlsaZg5ovU8odfi-images_1769001210582_na1fn_L2hvbWUvdWJ1bnR1L3ZlcmFfcnViaW5fbmV0d29ya19hcmNoaXRlY3R1cmU.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvWklHeGNGN2hzSUN5MXdsODRKUGxwUS9zYW5kYm94L2tDdGZNTGVLbHNhWmc1b3ZVOG9kZmktaW1hZ2VzXzE3NjkwMDEyMTA1ODJfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwzWmxjbUZmY25WaWFXNWZibVYwZDI5eWExOWhjbU5vYVhSbFkzUjFjbVUucG5nIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=QdjDfUrq-Fpo~rfdBNZZr49TmSJ2E1KgtW1pvdRo7XcCvnlrJjIhBe9cJ6sV3bieWto65b-lb8mS69Fp7WA3~HTdqMjrsx4IVzdYNW44CyuAoFvg0vVTw5HeMnR6SICZpHM7SPxOUhodkKYdi6r9N6wugJ2oebGhXOyq30ZDHA8BIDKKYqdHXMJ-EPXWmi3n9Gcsu1B5i7QynkpUs0DJFm6ebuO-yXM1RE2Cewyw8-a2Ycl~Y3lti-fA2mYw~lDSuTCWugBXx-h1cC898eBnUbrQtS43MCnYZbuJtBX8OftH4PMolEnQLDdt4L-kWpOfrF8DtH0JqyvFWOwVlUKXFQ__)
*圖 1: NVIDIA Vera Rubin NVL144 完整網絡架構，展示 Scale-up (NVLink 6) 和 Scale-out (Spectrum-X) 的分層設計*

## 二、NVLink 6 Scale-up 連接詳解

### 2.1 NVLink 6 的核心特性

NVLink 6 是 NVIDIA 第六代 GPU 互連技術，相比上一代 NVLink 5 實現了帶寬翻倍。其主要特性包括：

**帶寬提升**：NVLink 6 為每個 GPU 提供 14.4 Tbit/s 的帶寬，相比 NVLink 5 的 7.2 Tbit/s 提升了一倍。這種帶寬提升是通過採用雙向 SerDes（序列化/反序列化）技術實現的，使得數據可以在兩個方向上同時傳輸。

**Coherent 連接**：在 Vera Rubin NVL144 rack 中，9 個 NVLink 6 switches 將所有 72 個 GPU 連接成一個 coherent 系統。這意味著所有 GPU 可以直接訪問彼此的內存，無需顯式的數據複製，大大簡化了並行編程模型。

**系統級帶寬**：通過 9 個 NVLink 6 switches 的聚合，整個機架內的總帶寬達到 260 TB/s，為超大規模模型的訓練和推理提供了充足的帶寬。

### 2.2 NVLink 6 Switch 架構

在 Vera Rubin NVL144 rack 中，9 個 NVLink 6 switches 採用了特殊的拓撲結構，以最大化帶寬利用率：

```
GPU 0-3 ──┐
GPU 4-7 ──┼─→ NVLink 6 Switch 1 ──┐
GPU 8-11 ─┘                        │
                                   ├─→ NVLink 6 Switch 5 (Central)
GPU 12-15 ┐                        │
GPU 16-19 ┼─→ NVLink 6 Switch 2 ──┤
GPU 20-23 ┘                        │
                                   ├─→ NVLink 6 Switch 6
GPU 24-27 ┐                        │
GPU 28-31 ┼─→ NVLink 6 Switch 3 ──┤
GPU 32-35 ┘                        │
                                   └─→ NVLink 6 Switch 7-9
...
```

每個 switch 支持多個 GPU 的連接，形成了一個高度連接的網絡拓撲，確保任意兩個 GPU 之間的通信延遲最小化。

### 2.3 Scale-up 的應用場景

NVLink 6 的 scale-up 連接主要用於以下場景：

**模型並行**：當單個 GPU 的內存不足以容納整個模型時，可以將模型的不同層分配到不同的 GPU 上。通過 NVLink 6 的高帶寬連接，GPU 之間可以快速交換激活值和梯度，使得模型並行的效率接近單 GPU 訓練。

**張量並行**：在張量並行中，模型的權重矩陣被分割到多個 GPU 上。NVLink 6 的低延遲和高帶寬特性使得 all-reduce 操作（用於同步梯度）能夠高效執行。

**流水線並行**：通過 NVLink 6 的 coherent 內存模型，不同 GPU 上的流水線階段可以直接訪問彼此的中間結果，減少了同步開銷。

## 三、ConnectX-9 SuperNIC 的雙重角色

### 3.1 ConnectX-9 的規格

ConnectX-9 SuperNIC 是 Vera Rubin 架構中的關鍵網絡組件，它同時支持 scale-up 和 scale-out 連接：

| 特性 | 規格 |
| --- | --- |
| 網絡吞吐量 | 1.6 Tb/s per compute tray |
| 每個 Tray 的數量 | 4 個 ConnectX-9 板 |
| Ethernet 帶寬 | 800 Gb/s |
| 協議 | RoCE (RDMA over Converged Ethernet) |
| 集成功能 | PCIe Gen 6 switching + 800G Ethernet |

### 3.2 ConnectX-9 在 Scale-up 中的作用

雖然 NVLink 6 是 scale-up 的主要技術，但 ConnectX-9 在以下方面支持 scale-up 操作：

**CPU-GPU 通信**：每個 compute tray 包含 2 個 Vera CPU（88 核 ARM 處理器）。ConnectX-9 通過 NVLink-C2C（coherent 變體）與 CPU 連接，使 CPU 能夠直接訪問 GPU 內存，實現高效的 CPU-GPU 數據交換。

**系統管理**：ConnectX-9 負責收集系統健康信息、監控 GPU 溫度和功耗等，這些信息通過帶外管理網絡傳輸到系統控制器。

### 3.3 ConnectX-9 在 Scale-out 中的作用

![ConnectX-9 Dual Role](https://private-us-east-1.manuscdn.com/sessionFile/ZIGxcF7hsICy1wl84JPlpQ/sandbox/kCtfMLeKlsaZg5ovU8odfi-images_1769001210583_na1fn_L2hvbWUvdWJ1bnR1L2Nvbm5lY3R4OV9kdWFsX3JvbGU.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvWklHeGNGN2hzSUN5MXdsODRKUGxwUS9zYW5kYm94L2tDdGZNTGVLbHNhWmc1b3ZVOG9kZmktaW1hZ2VzXzE3NjkwMDEyMTA1ODNfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyTnZibTVsWTNSNE9WOWtkV0ZzWDNKdmJHVS5wbmciLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=Tz-E4jUG6KwzScfEbgS62ODo7rz~n4N9RKeoD-yI7OWNYBCPM3P3V2HhDXip6luLz5v1Lvbuz7tMjAhB7w89n5UQRkFV-jWgSMNKtMQatdXCtexdmS6zWnh34W1pUEigwWu42zZSAiVfGRY0PTxNaX~Ot9I9pxq5CLa287JP4G36T0RrKu66JOCCGtG-Mpjioqm8ubv7mmrrzYIcSAI2QUk68GROOK7Hs1wgZknprjnBwAKOFRS24PhLaDnJMwcDh28r4B7CY-3cV1kCEDSxs5Ybsu90tLz94zhIusewVoQvDaoJEMhvfbSlpLaY-nvxM6RVrJQE4OuaAXjO71OePg__)
*圖 2: ConnectX-9 SuperNIC 的雙重角色：同時支持 Scale-up 和 Scale-out*

ConnectX-9 的主要職責是實現機架間的 Ethernet 連接：

**Ethernet 端口**：每個 ConnectX-9 板提供 800 Gb/s 的 Ethernet 連接，支持 RoCE 協議。在 18 個 compute trays 的配置下，總共有 72 個 ConnectX-9 板，提供 28.8 TB/s 的聚合 Ethernet 帶寬。

**RoCE 優化**：ConnectX-9 實現了 NVIDIA 的 RoCE 擴展，包括 GPUDirect RDMA 支持，使得 GPU 可以直接通過 Ethernet 訪問遠程 GPU 的內存，無需 CPU 干預。

**性能隔離**：ConnectX-9 支持虛擬隊列（Virtual Queues）和優先級隊列，確保不同應用的網絡流量不會相互干擾。

## 四、Spectrum-X Scale-out 架構

### 4.1 Spectrum-X 平台概述

Spectrum-X 是 NVIDIA 專為 AI 工作負載設計的 Ethernet 網絡平台，包括 Spectrum-X Ethernet switches 和 Spectrum-X Ethernet SuperNICs。

| 組件 | 功能 |
| --- | --- |
| **Spectrum-X Switches** | 提供 scale-out 連接，支持 800 Gb/s 端口 |
| **Spectrum-X SuperNICs** | 端點網卡，與 ConnectX-9 集成 |
| **SONiC 軟件棧** | 開放的網絡操作系統 |

### 4.2 Spectrum-X 交換機架構

Spectrum-X 交換機採用了針對 AI 工作負載優化的設計：

**高有效帶寬**：相比標準 Ethernet 交換機，Spectrum-X 通過優化的擁塞控制算法和精確的延遲管理，實現了 1.6 倍的性能提升。

**低延遲**：Spectrum-X 的設計目標是最小化網絡延遲，特別是對於 all-reduce 等集合操作。通過硬件支持的優先級隊列和無丟包 Ethernet，Spectrum-X 能夠提供極低且可預測的延遲。

**可擴展性**：Spectrum-X 支持從數十個 GPU 到數百萬個 GPU 的規模，通過分層的交換機架構和拓撲感知的路由算法實現。

### 4.3 Spectrum-X 與 ConnectX-9 的集成

ConnectX-9 SuperNIC 與 Spectrum-X 交換機無縫集成，形成完整的 scale-out 網絡：

```
GPU Server 1 ──→ ConnectX-9 ──→ Spectrum-X Switch ──→ ConnectX-9 ← GPU Server 2
                  (800 Gb/s)      (Fabric)           (800 Gb/s)
```

**GPUDirect RDMA**：ConnectX-9 支持 GPUDirect RDMA，使得遠程 GPU 可以直接讀寫本地 GPU 的內存，無需通過 CPU。這對於高效的分佈式訓練至關重要。

**RoCE 優化**：ConnectX-9 實現了 NVIDIA 的 RoCE 擴展，包括 ECN（Explicit Congestion Notification）支持，使得 Spectrum-X 交換機能夠精確控制網絡流量。

## 五、完整的網絡連接流程

### 5.1 單機架內的通信（Scale-up）

當兩個 GPU 在同一個 Vera Rubin NVL144 rack 內通信時，數據流如下：

![Scale-up and Scale-out Flow](https://private-us-east-1.manuscdn.com/sessionFile/ZIGxcF7hsICy1wl84JPlpQ/sandbox/kCtfMLeKlsaZg5ovU8odfi-images_1769001210583_na1fn_L2hvbWUvdWJ1bnR1L3NjYWxlX3VwX3NjYWxlX291dF9mbG93.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvWklHeGNGN2hzSUN5MXdsODRKUGxwUS9zYW5kYm94L2tDdGZNTGVLbHNhWmc1b3ZVOG9kZmktaW1hZ2VzXzE3NjkwMDEyMTA1ODNfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwzTmpZV3hsWDNWd1gzTmpZV3hsWDI5MWRGOW1iRzkzLnBuZyIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=GPTSUPqTLT10b92-5LT3y6JaVI2Zr-T7AWyr4gnqo5wEFvVEEp5hYoibJOXBoaZ-AfyczR8Ag-AN1j800MYepyXs6-CDz6TlaAYn-l8Tx77yXt53s1GYtYVJ~9VP-vAE9hAd~jrJOKt14yaVbWoRVPFLIJURkCV0-gzHrNiWKF53G-4L91nAzxUBzSL5Ppi-Zh6qHsaQbCiuEpY0yjEV3G8rE96n9RBvTfI1nSNacsYElnhe3csWsWM7YURR0zv1ncFmhU7Zo--CGEZOs5pgMK6DLTSo2O1ZB79gbQus2i8AWQhB29vj70xc0JRVgc-uq96O7oPqgCfV4rrC8h2JXA__)
*圖 3: Intra-Rack (Scale-up) 和 Inter-Rack (Scale-out) 通信流程對比*

**特點**：
- 直接的 NVLink 6 連接，無需經過 Ethernet
- 帶寬：14.4 Tbit/s (per GPU)
- 延遲：< 1 微秒
- Coherent 內存模型：GPU 可以直接訪問彼此的內存

### 5.2 跨機架的通信（Scale-out）

當兩個 GPU 在不同的 Vera Rubin rack 內通信時，數據流如圖 3 右側所示：

**特點**：
- 通過 Spectrum-X Ethernet 連接
- 帶寬：800 Gb/s (per ConnectX-9 port)
- 延遲：~ 1-2 微秒 (取決於距離)
- RoCE 協議支持 GPUDirect RDMA

### 5.3 混合通信模式

在實際的分佈式訓練中，通常會同時使用 scale-up 和 scale-out 連接：

```
AllReduce 操作（4 個 Rack，每個 Rack 18 個 Tray，每個 Tray 4 個 GPU）

Step 1: 本地 Reduce (Tray 內)
GPU 0 ──→ GPU 1 ──→ GPU 2 ──→ GPU 3 (via NVLink 6)

Step 2: Rack 內 Reduce (Tray 間)
Tray 1 ──→ Tray 2 ──→ ... ──→ Tray 18 (via NVLink 6 + ConnectX-9)

Step 3: 跨 Rack Reduce
Rack 1 ──→ Rack 2 ──→ Rack 3 ──→ Rack 4 (via Spectrum-X Ethernet)

Step 4: AllGather (反向傳播)
```

## 六、網絡配置最佳實踐

### 6.1 Scale-up 優化

**親和性設置**：將需要頻繁通信的 GPU 分配到同一個 tray 或相鄰的 tray，以最大化 NVLink 6 的利用率。

**流量隔離**：使用 ConnectX-9 的虛擬隊列功能，將不同應用的流量隔離，防止一個應用的流量影響其他應用。

**監控和調試**：使用 NVIDIA 的 DCGM（Data Center GPU Manager）監控 NVLink 6 的帶寬利用率和錯誤率。

### 6.2 Scale-out 優化

**拓撲感知調度**：根據 Spectrum-X 交換機的拓撲，調度 GPU 任務，使得通信流量集中在交換機的高帶寬路徑上。

**擁塞控制**：啟用 Spectrum-X 的 ECN 支持，使得交換機能夠動態調整流量速率，防止擁塞。

**負載均衡**：使用 ECMP（Equal-Cost Multi-Path）路由，將流量均勻分散到多條路徑上，提高帶寬利用率。

### 6.3 混合模式優化

**階層化通信**：將 all-reduce 等集合操作分為多個階段，先在 tray 內進行（使用 NVLink 6），再在 rack 內進行（使用 NVLink 6），最後在 rack 間進行（使用 Spectrum-X）。

**批量操作**：將多個小的通信操作合併成一個大的操作，減少通信開銷。

**異步通信**：使用異步的 GPU 通信操作，允許計算和通信重疊，提高整體效率。

## 七、Co-Packaged Optics (CPO) 的未來

### 7.1 Rubin Ultra (Kyber) 中的 CPO

在 Rubin Ultra 架構中，NVIDIA 計劃採用 Co-Packaged Optics (CPO) 技術，將光學引擎與交換機 ASIC 集成在同一個封裝中。

**優勢**：
- 消除 DSP（數字信號處理器）的需求，降低功耗
- 支持更高的帶寬密度（14.4 Tbit/s per GPU）
- 更低的延遲（無需光電轉換）
- 更高的可靠性（集成度更高）

### 7.2 CPO 的應用前景

CPO 技術將使得 scale-up 域可以擴展到多個機架，實現真正的"超級計算機"級別的 GPU 集群。這將改變當前的網絡架構，使得 scale-up 和 scale-out 的界限變得模糊。

## 結論

Vera Rubin 的網絡架構通過 ConnectX-9 SuperNIC、NVLink 6 和 Spectrum-X 的有機結合，實現了從單機架到超大規模 GPU 集群的無縫擴展。NVLink 6 提供了機架內的高速、低延遲連接，而 Spectrum-X 則提供了機架間的高效、可擴展連接。ConnectX-9 作為中樞，同時支持兩種連接模式，使得系統設計更加簡潔高效。

隨著 CPO 技術的成熟和部署，未來的 AI 基礎設施將能夠支持更大規模的模型訓練和推理，推動 AI 技術的進一步發展。

## 參考資料

[1] NVIDIA Developer Blog. "Inside the NVIDIA Rubin Platform: Six New Chips, One AI Supercomputer." https://developer.nvidia.com/blog/inside-the-nvidia-rubin-platform-six-new-chips-one-ai-supercomputer/

[2] NVIDIA. "Spectrum-X Ethernet Networking Platform." https://www.nvidia.com/en-us/networking/spectrumx/

[3] NVIDIA Developer Blog. "NVIDIA ConnectX-8 SuperNICs Advance AI Platform Architecture." https://developer.nvidia.com/blog/nvidia-connectx-8-supernics-advance-ai-platform-architecture-with-pcie-gen6-connectivity/

[4] NVIDIA News. "NVIDIA Kicks Off the Next Generation of AI With Rubin." https://nvidianews.nvidia.com/news/rubin-platform-ai-supercomputer

[5] Convergedigest. "NVLink 6 Becomes the Backbone of Rubin Rack-Scale AI Architecture." https://convergedigest.com/nvlink-6-becomes-the-backbone-of-rubin-rack-scale-ai-architecture/
