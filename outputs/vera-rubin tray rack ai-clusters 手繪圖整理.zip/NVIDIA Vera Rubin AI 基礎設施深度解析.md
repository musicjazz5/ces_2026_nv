# NVIDIA Vera Rubin AI 基礎設施深度解析

**作者**: Manus AI
**日期**: 2026年1月21日

## 引言

本報告旨在深入解析 NVIDIA 新一代 AI 基礎設施的核心——Vera Rubin 架構，涵蓋其主要組件、設計理念及不同配置下的技術規格。通過整理和分析來自 semi-analysis 的權威文章，我們將探討 Vera Rubin、Rubin CPX 及 Rubin Ultra (Kyber) 在 AI 計算集群中的 tray、rack 級別設計，並提供相關示意圖以助理解。

## Vera Rubin (VR200) 架構：新一代 AI 計算引擎

NVIDIA 的 Vera Rubin 架構代表了 AI 硬件的又一次重大飛躍，其設計旨在滿足日益增長的模型複雜度和推理需求。VR200 作為該系列的核心，通過創新的系統設計，提供了前所未有的計算密度和效率。

### VR200 NVL144 Rack

VR200 NVL144 是 Vera Rubin 架構的標準機架配置，其設計延續了前代 Oberon rack 的成功經驗，但在多個方面進行了顯著升級。根據 semi-analysis 的報導 [1]，NVL144 的命名遵循了 NVIDIA 最新的“Jensen Math”第三規則，即以 GPU die 的數量而非 GPU package 的數量來命名。因此，儘管名為 NVL144，該機架實際上包含 72 個 GPU package。

以下是 VR200 NVL144 的關鍵規格：

| 組件 | 規格 |
| --- | --- |
| GPU Packages | 72 個 R200 GPU 包 |
| GPU Dies | 144 個 GPU dies |
| Compute Trays | 18 個 |
| 每個 Tray 配置 | 4 個 R200 GPU 包 |
| CPU | 144 個 Vera CPU |
| 系統內存 | 218 TB LPDDR (每個 CPU 1.5TB) |

![NVIDIA Vera Rubin Compute Tray](https://private-us-east-1.manuscdn.com/sessionFile/ZIGxcF7hsICy1wl84JPlpQ/sandbox/kCtfMLeKlsaZg5ovU8odfi-images_1769001210792_na1fn_L2hvbWUvdWJ1bnR1L0JYcWtwQzFUVm9MQQ.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvWklHeGNGN2hzSUN5MXdsODRKUGxwUS9zYW5kYm94L2tDdGZNTGVLbHNhWmc1b3ZVOG9kZmktaW1hZ2VzXzE3NjkwMDEyMTA3OTJfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwwSlljV3R3UXpGVVZtOU1RUS5wbmciLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=YRdHaZQWkibM5cVrWUp8zgx5zOtcCUaiaMWT4ikeEqpwyDyr93FEWEdz4Nw416K6tLmgL8Cp1aOsfaZTQZsj4YU2BMF4SeXFrOvaZdNuvilOGwYp6qUAc~~tNrlB8NfWbhueBpPZYkXjIWNW17yTtOMYlRiUvy5jGkNZZbdns9eBhHCYRsykQ702lYk8ze67Fdxmhrco3ECh3~Tfmj~dsAuxNWIGNKeKwYpAtRcHWNuRYRqN6OL3SZBHLsIknI7s-hmAJ4lDffbao8h-M5Bu6Bj48SR5Wrdc6wL-WZOZ0peAxyAC~Y8lPneQBKXHzUY3tqg6baUfmLgHWfd6SF08IA__)
*圖 1: NVIDIA Vera Rubin Compute Tray 示意圖 [4]*

### R200 GPU 核心規格

R200 GPU 作為 Vera Rubin 架構的計算核心，其性能相比上一代 B300 有了超過三倍的提升。這得益於其採用了台積電（TSMC）的 3nm 工藝，並集成了兩個全尺寸的計算芯片。

| 特性 | 規格 |
| --- | --- |
| 計算性能 (FP4 Dense) | 33.3 PFLOPs |
| 內存類型 | HBM (High Bandwidth Memory) |
| 內存容量 | 288 GB |
| 內存帶寬 | 20.5 TB/s |
| 網絡 | NVLink, CX-8 NIC (800G InfiniBand) |

![NVIDIA Rubin Platform](https://private-us-east-1.manuscdn.com/sessionFile/ZIGxcF7hsICy1wl84JPlpQ/sandbox/kCtfMLeKlsaZg5ovU8odfi-images_1769001210793_na1fn_L2hvbWUvdWJ1bnR1L1BoMDFGZEtZTFIydw.webp?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvWklHeGNGN2hzSUN5MXdsODRKUGxwUS9zYW5kYm94L2tDdGZNTGVLbHNhWmc1b3ZVOG9kZmktaW1hZ2VzXzE3NjkwMDEyMTA3OTNfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwxQm9NREZHWkV0WlRGSXlkdy53ZWJwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=Pq8ySC6K2uNXq5d148dxnECP0P2JgBHV2WRVf3t8rGzBoiWYyIDe2nSI8y1pGRYgh7t~eZo8r4xcAG6AK~rS0RMhZlzC1ZK6VCeO~B71buaxZA0NqWEfkSrZeXc~y-eTB8jmT-GyETDLNNBbT0I3h9kxcgaIYeHf8n2H-e2wdU9tz44MSvnbvuaxVWGOjzO-53iiYskWYDMcONEK29NC8E4K0f8e-9xhvJImaXaaXA7svAPCGY0gnZoqFbCz4~Kav3cVqYSsd5rVEEaDJr0PmncFYeYJQqn0oRZCPU071XxFumCgw9e5l3xvKAhNFUelrZn~TPgFLTp6Iz9EtQp9Qg__)
*圖 2: NVIDIA Rubin 平台芯片組 [7]*

## Rubin CPX：針對 Prefill 優化的專用加速器

為了應對大語言模型推理中 Prefill 和 Decode 階段的不同計算需求，NVIDIA 推出了 Rubin CPX，一款專為 Prefill 優化的加速器。其核心設計理念是“瘦內存帶寬，胖計算能力”，通過犧牲部分內存帶寬來換取更高的計算性能和更低的成本。

### Rubin CPX 與 R200 規格對比

根據 semi-analysis 的深入分析 [2]，Rubin CPX 採用了成本更低的 GDDR7 內存，使其每 GB 成本降低了 50% 以上。下表對比了 R200 和 Rubin CPX 的主要規格：

| 特性 | R200 GPU | Rubin CPX GPU |
| --- | --- | --- |
| 計算性能 (FP4 Dense) | 33.3 PFLOPs | 20 PFLOPs |
| 內存類型 | HBM | GDDR7 |
| 內存容量 | 288 GB | 128 GB |
| 內存帶寬 | 20.5 TB/s | 2.0 TB/s |
| 功耗 | ~1500W (估計) | ~800W |
| 網絡 | NVLink, PCIe Gen 6 | PCIe Gen 6 |

### VR200 Rack 的三種 CPX 配置

Rubin CPX 的引入為 VR200 rack 帶來了三種靈活的配置選項，以滿足不同場景的需求：

1.  **VR200 NVL144**：標準配置，包含 72 個 R200 GPU。
2.  **VR200 NVL144 CPX**：混合配置，在每個 compute tray 中集成 4 個 R200 GPU 和 8 個 Rubin CPX GPU，總計 72 個 R200 和 144 個 CPX。
3.  **Vera Rubin CPX Dual Rack**：雙機架方案，一個機架滿配 72 個 R200 GPU，另一個機架滿配 144 個 Rubin CPX GPU。

![Vera Rubin CPX Dual Rack](https://private-us-east-1.manuscdn.com/sessionFile/ZIGxcF7hsICy1wl84JPlpQ/sandbox/kCtfMLeKlsaZg5ovU8odfi-images_1769001210793_na1fn_L2hvbWUvdWJ1bnR1L0VLM1hSRlFoZmZHRQ.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvWklHeGNGN2hzSUN5MXdsODRKUGxwUS9zYW5kYm94L2tDdGZNTGVLbHNhWmc1b3ZVOG9kZmktaW1hZ2VzXzE3NjkwMDEyMTA3OTNfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwwVkxNMWhTUmxGb1ptWkhSUS5wbmciLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=WIuadb2Py6X9C3yjnFo4LrXqP6Fs7jfZpe~zLP9YX~8vxAH~-wjnAFg71AFGqNEO0Agx6feHgAndvKb7pv6w2CoQQdrv5BgSbJD0y4QtVXK-ovi1gYmRg5lOP~nhje-KaVnsKgI6EZNWfsMXTqC1boilZwRtX4jhKUxYSDpNI9Ng4pqm~Y1gFCoddtY5uOTO9AAk7RU7Jheva78-COZNzTmbG80BXdYMtNb96utD0kxr-qe2QZKvx1DNXjQGAmxV2b3FmY4ONBqNIFvXZDumo2M3FL7Q1ywklfgwEUlDsvWMLh38Ypun2u27vNVcJmdUEyPihn45JRN8FUWrCVVR4g__)
*圖 3: Vera Rubin CPX Dual Rack 概念圖 [5]*

在雙機架配置下，整個系統的總內存帶寬可達 1.7 PB/s，為處理超大規模模型提供了強大的支持。

## Rubin Ultra (Kyber) 架構：邁向光學互連的未來

隨著 AI 模型規模的持續擴張，傳統的銅基互連技術逐漸逼近其物理極限。為此，NVIDIA 推出了 Rubin Ultra，代號 Kyber，這是一個採用了 Co-Packaged Optics (CPO) 技術的極端密集型機架架構。

### Kyber Rack 的極致密度

根據 semi-analysis 的分析 [3]，Kyber rack 的設計極具野心，其密度是 GB200/300 NVL72 的四倍：

| 組件 | 規格 |
| --- | --- |
| GPU Packages | 144 個 |
| GPU Dies | 576 個 |
| 網絡帶寬 (per GPU) | 14.4 Tbit/s |
| 互連技術 | Co-Packaged Optics (CPO) |

這種極高的密度對供電和散熱提出了前所未有的挑戰，也預示著數據中心的設計將迎來根本性的變革。

### Co-Packaged Optics (CPO) 的核心作用

CPO 技術將光學引擎與計算芯片封裝在一起，從而克服了銅線在帶寬和距離上的限制。其主要優勢包括：

-   **超高帶寬**：為每個 GPU 提供高達 14.4 Tbit/s 的 scale-up 帶寬。
-   **更低能耗**：相比傳統光模塊，CPO 可將傳輸能耗降低 50% 至 80%。
-   **更大規模**：使 scale-up 域可以擴展到多個機架，實現更大規模的計算集群。

![Co-Packaged Optics on Substrate](https://private-us-east-1.manuscdn.com/sessionFile/ZIGxcF7hsICy1wl84JPlpQ/sandbox/kCtfMLeKlsaZg5ovU8odfi-images_1769001210794_na1fn_L2hvbWUvdWJ1bnR1L1VaYUt4T254ZFROQg.jpg?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvWklHeGNGN2hzSUN5MXdsODRKUGxwUS9zYW5kYm94L2tDdGZNTGVLbHNhWmc1b3ZVOG9kZmktaW1hZ2VzXzE3NjkwMDEyMTA3OTRfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwxVmFZVXQ0VDI1NFpGUk9RZy5qcGciLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=n3B5nTIEyzIH-eF0HEpBf8X1RKyZIwX02sPjyUrTVS1ZPtCo~w~iyFhUU648liyQ32O7~yoPjCauAmtEsBaUvMXuydQaFguw9C8unxlLMjj6y1LwUeupUTYonZeWG~7hrnWhRyYnELug1kkhMbd1M2p8ar~ZfrfBHG9RkJYSCikg-B5nxeKvz237A3kROg1w11BdsCj~BFCtHzJ000DuAfMN~fJrdYjiyGHLpL5g6LkzNW5yXtoOPJNrbabM~Z4Cz1QJZHilJjlf4x~uq7M2xaKn-Z7ukO6WJF54oC878wAxN1Z1sBMNfzqHoLz~QFUYqNt9d3aEOiMXONSdXnw~ww__)
*圖 4: Co-Packaged Optics (CPO) 結構示意圖 [1]*

## 結論

NVIDIA 的 Vera Rubin 系列架構通過模塊化和專用化的設計，為 AI 基礎設施的未來發展指明了方向。從標準的 VR200 NVL144，到針對 Prefill 優化的 Rubin CPX，再到面向未來的 Rubin Ultra (Kyber) 光學互連架構，NVIDIA 正在構建一個能夠應對從當前到未來十年 AI 計算挑戰的完整生態系統。隨著這些技術的逐步落地，我們有理由相信，AI 的能力邊界將被再次拓寬。

## 參考資料

[1] Patel, D., et al. (2025, March 19). *NVIDIA GTC 2025 - Built For Reasoning, Vera Rubin, Kyber, CPO, Dynamo Inference, Jensen Math, Feynman*. SemiAnalysis. https://newsletter.semianalysis.com/p/nvidia-gtc-2025-built-for-reasoning-vera-rubin-kyber-cpo-dynamo-inference-jensen-math-feynman

[2] Patel, D., et al. (2025, September 11). *Another Giant Leap: The Rubin CPX Specialized Accelerator & Rack*. SemiAnalysis. https://newsletter.semianalysis.com/p/another-giant-leap-the-rubin-cpx-specialized-accelerator-rack

[3] Patel, D., et al. (2026, January 2). *Co-Packaged Optics (CPO) Book – Scaling with Light for the Next Wave of Interconnect*. SemiAnalysis. https://newsletter.semianalysis.com/p/co-packaged-optics-cpo-book-scaling

[4] Storage Review. (2026, January 5). *NVIDIA Launches Vera Rubin Architecture at CES 2026: The VR...*. https://www.storagereview.com

[5] Introl. (2027). *NVIDIA Vera Rubin: 600kW Racks by 2027*. https://introl.com
