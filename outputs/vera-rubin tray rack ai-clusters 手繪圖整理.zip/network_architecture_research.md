# Vera Rubin 網絡架構研究筆記

## ConnectX 網卡在 Vera Rubin 中的角色

### ConnectX-9 SuperNIC 規格
- **網絡吞吐量**: 1.6 Tb/s 每個 compute tray
- **位置**: 每個 compute tray 有 4 個 ConnectX-9 SuperNIC 板
- **協議**: 800 Gb/s Ethernet (RoCE)
- **功能**: 同時支持 scale-up 和 scale-out 連接

### 系統級網絡帶寬
- **Vera Rubin NVL144 Rack**: 18 個 compute trays
- **每個 tray 的 ConnectX-9**: 1.6 Tb/s
- **總系統 Ethernet 帶寬**: 28.8 TB/s

## NVLink 6 Scale-up 架構

### NVLink 6 規格
- **帶寬**: 14.4 Tbit/s 每 GPU（相比 NVLink 5 的 7.2 Tbit/s）
- **交換機**: 9 個 NVLink 6 switches 在 Vera Rubin NVL144 rack
- **總帶寬**: 260 TB/s (垂直擴展)
- **功能**: 使 72 個 GPUs 在 rack 內作為單一連貫加速器

### NVLink 6 Switch 架構
- 在 Vera Rubin NVL72 rack 中使用 9 個 NVLink 6 switches
- 提供 GPU 之間的 coherent 連接
- 支持 tensor parallelism 和 pipeline parallelism

## Spectrum-X Scale-out 架構

### Spectrum-X 平台組成
1. **Spectrum-X Ethernet Switches**: 用於 scale-out 連接
   - Spectrum SN5000 系列
   - Spectrum SN6000 系列
   - 支持 800 Gb/s 端口

2. **Spectrum-X Ethernet SuperNICs**: 端點網卡
   - 提供高帶寬 RDMA over Converged Ethernet (RoCE)
   - 與 ConnectX 系列集成

### Spectrum-X 性能指標
- **性能提升**: 相比標準 Ethernet 提升 1.6x
- **延遲**: 極低延遲設計
- **可擴展性**: 支持數百萬 GPU 規模

## Scale-up 與 Scale-out 的集成

### Scale-up (NVLink 6)
- **範圍**: 單個機架內 (最多 2 米)
- **帶寬**: 14.4 Tbit/s per GPU
- **用途**: GPU 間高速通信，支持模型並行
- **技術**: NVLink 6 switches + ConnectX-9 SuperNIC

### Scale-out (Spectrum-X)
- **範圍**: 跨機架、跨數據中心
- **帶寬**: 800 Gb/s per port (可聚合)
- **用途**: 機架間通信，支持數據並行
- **技術**: Spectrum-X switches + Ethernet SuperNICs

## ConnectX-9 在混合架構中的作用

### 雙重角色
1. **Scale-up 支持**: 通過 NVLink-C2C 與 CPU 連接
2. **Scale-out 支持**: 通過 Ethernet 連接到 Spectrum-X 交換機

### 集成優勢
- 單一網卡支持兩種連接模式
- 減少板卡數量和功耗
- 簡化系統設計

## Co-Packaged Optics (CPO) 的未來方向

### Rubin Ultra (Kyber) 中的 CPO
- 將光學引擎與交換機 ASIC 集成
- 支持 14.4 Tbit/s 的 scale-up 帶寬
- 減少功耗和延遲

## 來源
- NVIDIA Developer Blog: "Inside the NVIDIA Rubin Platform"
- NVIDIA Spectrum-X 官方頁面
- SemiAnalysis 研究報告
