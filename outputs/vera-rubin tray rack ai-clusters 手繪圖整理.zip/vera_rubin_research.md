# Vera Rubin 架構研究筆記

## 來源
- Semi-Analysis Newsletter: NVIDIA GTC 2025 - Built For Reasoning, Vera Rubin, Kyber, CPO, Dynamo Inference
- URL: https://newsletter.semianalysis.com/p/nvidia-gtc-2025-built-for-reasoning-vera-rubin-kyber-cpo-dynamo-inference-jensen-math-feynman

## 關鍵發現

### Vera Rubin GPU 規格
- **計算性能**: 50 PFLOPs 的密集 FP4 計算能力
- **相比 B300 的提升**: 超過 3 倍的性能提升
- **芯片設計**: 兩個 TSMC 3nm 的全尺寸計算芯片
- **I/O 架構**: 兩個 I/O 瓦片，包含所有 NVLink、PCIe 和 NVLink C2C IP 的 SerDes

### Vera Rubin NVL144 Rack 架構
- **命名規則**: 第一代 Vera Rubin racks 稱為 NVL144（基於 GPU dies 計數）
- **系統架構**: 類似於 GB200 NVL72 的 Oberon rack
- **GPU 包數**: 72 個 GPU 包
- **內存配置**: 每個 Vera CPU 有 1.5TB 的 LPDDR
  - 144 個 Vera CPUs × 1.5TB = 總計 218TB LPDDR

### Jensen Math 第三規則
- GPU 計數現在按 GPU dies 而非 GPU packages 計算
- 這導致命名混亂：NVL144 實際上只有 72 個 GPU packages
- 從 Rubin 開始採用此命名規則

### 網絡升級
- **CX-8 NIC**: 提供 4 個 200G 通道，總計 800G 吞吐量
- **InfiniBand 升級**: 相比 CX-7 NIC 的 Blackwell 一代翻倍的網絡速度

### Tray 相關信息
- 文章提到 Vera Rubin CPX 架構中有 18 個計算 trays
- 每個 tray 包含 144 個 Rubin CPX GPUs

## 待搜索的其他資源
- 需要找到 semi-analysis 上的 "Another Giant Leap: The Rubin CPX Specialized Accelerator & Rack" 文章
- 需要找到具體的手繪圖或架構圖


## Rubin CPX 架構詳細信息

### Rubin CPX 芯片規格
- **計算性能**: 20 PFLOPs FP4 密集計算（30 PFLOPs 稀疏）
- **內存配置**: 128GB GDDR7 DRAM（而非 HBM）
- **內存帶寬**: 2TB/s（相比 R200 的 20.5TB/s）
- **功耗**: 約 800W
- **封裝**: 單芯片 SoC，採用傳統 flip chip BGA 封裝
- **網絡**: PCIe Gen 6（無 NVLink SerDes）

### Rubin CPX 設計理念
Rubin CPX 針對推理的 prefill 階段進行優化，該階段計算密集但內存帶寬利用率低。通過使用廉價的 GDDR7 而非 HBM，成本降低超過 50%。

### VR200 Rack 系列的三種配置

#### 1. VR200 NVL144
- **GPU 包數**: 72 個 R200 GPU 包
- **Compute Trays**: 18 個
- **每個 Tray 配置**: 4 個 R200 GPU 包

#### 2. VR200 NVL144 CPX（混合配置）
- **R200 GPU 包**: 72 個
- **Rubin CPX GPU 包**: 144 個
- **Compute Trays**: 18 個
- **每個 Tray 配置**: 4 個 R200 GPU 包 + 8 個 Rubin CPX GPU 包

#### 3. Vera Rubin CPX Dual Rack（雙機架）
- **機架 1**: VR200 NVL144（72 個 R200 GPUs）
- **機架 2**: VR CPX（144 個 Rubin CPX GPUs）
- **Compute Trays**: 18 個（每個機架）
- **CPX Tray 配置**: 每個 tray 有 8 個 Rubin CPX GPUs

### 系統級內存帶寬
- **144 個 CPX 芯片**: 2.0 TB/s × 144 = 288 TB/s
- **72 個 R200 芯片**: 20.5 TB/s × 72 = 1,476 TB/s
- **總系統帶寬**: 1.7 PB/s

### 網絡配置
- **CPX 網絡**: PCIe Gen 6，通過 CX-9 NICs 進行 scale-out 通信
- **R200 網絡**: NVLink 用於 scale-up 通信

## 來源
- Semi-Analysis Newsletter: "Another Giant Leap: The Rubin CPX Specialized Accelerator & Rack"
- URL: https://newsletter.semianalysis.com/p/another-giant-leap-the-rubin-cpx-specialized-accelerator-rack
- 發布日期: 2025 年 9 月 11 日


## Rubin Ultra - Kyber Rack 架構

### Kyber Rack 規格
- **GPU 包數**: 144 個 GPU 包
- **GPU Dies 數**: 576 個 GPU dies（4 倍於 GB200/300 NVL72）
- **密度**: 相比 GB200/300 NVL72 rack 提升 4 倍
- **網絡帶寬**: 14.4 Tbit/s 每 GPU（相比 Rubin 的 7.2 Tbit/s）

### Kyber Rack 的設計挑戰
Kyber rack 採用極端的 Rubin Ultra 架構，將 Oberon 架構的功率密度推至極限，需要顯著升級功率傳輸設計。

### NVLink 和 CPO 升級
- **Rubin 代 NVLink 帶寬**: 14.4 Tbit/s 每 GPU（相比 GB200/300 的 7.2 Tbit/s）
- **銅基連接限制**: 最多 2 米範圍，限制 scale-up 域大小為 1-2 個機架
- **CPO 的作用**: 在 scale-up 網絡中扮演關鍵角色，提供更大的 scale-up 域

### CPO 技術優勢
相比傳統 DSP 收發器，CPO 可以：
- 減少 50% 以上的傳輸能耗
- 某些設計可減少 80% 的每比特能耗
- 消除 DSP 的需求，使用更低功耗的 SerDes

## 來源
- Semi-Analysis Newsletter: "Co-Packaged Optics (CPO) Book – Scaling with Light for the Next Wave of Interconnect"
- URL: https://newsletter.semianalysis.com/p/co-packaged-optics-cpo-book-scaling
- 發布日期: 2026 年 1 月 2 日
